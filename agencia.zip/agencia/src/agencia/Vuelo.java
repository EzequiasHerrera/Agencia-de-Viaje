/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agencia;

public class Vuelo {
    
    //Atributos
    private String num_vuelo;
    private Date fecha_hora;
    private String origen;
    private String destino;
    private Integer plazas_totales;
    private Integer plazas_turista_disponible;
    
    //Constructor
    public Vuelo (String num_vuelo, Date fecha_hora, String origen, String destino, Integer plazas_totales, Integer plazas_turista_disponible)
    {
        this.num_vuelo = num_vuelo;
        this.fecha_hora = fecha_hora;
        this.origen = origen;
        this.destino = destino;
        this.plazas_totales = plazas_totales;
        this.plazas_turista_disponible = plazas_turista_disponible;
    }
     
}
