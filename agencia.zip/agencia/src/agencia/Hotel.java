/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agencia;

public class Hotel {
    
    //Atributos
    private String codigo;
    private String direccion;
    private String ciudad;
    private String telefono;
    private int plazas_disponibles;
    
    //Constructor
    public Hotel (String codigo, String direccion, String ciudad, String telefono, Integer plazas_disponibles)
    {
        this.codigo = codigo;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.telefono = telefono;
        this.plazas_disponibles = plazas_disponibles;
    }
    
}
