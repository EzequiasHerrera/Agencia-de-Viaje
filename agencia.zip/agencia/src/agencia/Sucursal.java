/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agencia;

public class Sucursal {
    
    //Atributos
    private String codigo;
    private String direccion;
    private String mail;
    private String telefono;
    
    //Constructor
    public Sucursal (String codigo, String direccion, String mail, String telefono)
    {
        this.codigo = codigo;
        this.direccion = direccion;
        this.mail = mail;
        this.telefono = telefono;
    }
    
}
